# K-Means Synthetic Datasets

## Input datasets
kmeans1.csv and kmeans2.csv both have 2 features and 2000 datapoints, and form 2 very nicely separate circular clusters. It is a minimum requirement that k-means should be able to cluster kmeans1.csv correctly. However, kmeans2.csv has unequally scaled features which can be problematic with naive k-means.

kmeans_mixture.csv is a mixture of several Gaussian distributions. It has 4 features and 500 datapoints which form an unknown number of clusters. Try to determine both the optimal cluster centers and the optimal number of clusters.