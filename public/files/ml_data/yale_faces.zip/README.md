# Yale Faces Dimensionality Reduction
We can greatly reduce the dimensionality of a face image of dimension 1024 to a much smaller space using PCA. 

# Input File
The file yale_faces.csv contains 2414 grayscale 32x32 images, with one image per row.