//
//  AppDelegate.swift
//  MetalFinal
//
//  Created by Donald Pinckney on 7/30/18.
//  Copyright © 2018 donaldpinckney. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {



    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }


}

